# ARK Diagnostic Centre
Ready-to-upload static website.
Phone: 9398908582
Address: Bus Stand Back Side, Beside Dr. Vijay Kumar Clinic, Subhash Nagar, Kalwakurthy, Nagarkurnool District.
Upload all files to the ROOT of the GitHub repository. `index.html` must be in the root.